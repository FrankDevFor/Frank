#include <iostream>
#include "ArrayList.h"
using namespace std;

int main()
{

    int maxSize;
    int choice;

    cout << "Enter the maxsize of the ArrayList: ";
    cin >> maxSize;

    ArrayList list(maxSize);

do {
        cout << "\nWelcome to Lab ArrayList" << endl;
        cout << "1. size()" << endl;
        cout << "2. indexOf(int e)" << endl;
        cout << "3. get(int i)" << endl;
        cout << "4. set(int i, int e)" << endl;
        cout << "5. remove(int i)" << endl;
        cout << "6. add(int i, int e)" << endl;
        cout << "7. display()" << endl;
        cout << "8. min()" << endl;
        cout << "9. max()" << endl;
        cout << "10.clear()" << endl;
        cout << "11.isempty()" << endl;
        cout << "0. Exit" << endl;
        cout << "" << endl;

        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) 
        {

            case 1: 
            {
                int curSize = list.size();
                cout << "Array size : " << curSize << endl;

                break;
            }

            case 2: 
            {
                int e;

                cout << "Enter element to find index : ";
                cin >> e;

                int index =list.indexOf(e);

                if (index != -1)
                    cout << "Element " << e << " is at index : " << index << endl;

                else
                    cout << "Element not found." << endl;

                break;
            }

            case 3: {
                int index;

                cout << "Enter index to get element : ";
                cin >> index;

                int e =list.get(index);

                if (e != -1)
                    cout << "Element at index " << index << " ; " << e << endl;

                break;
            }

            case 4: 
            {
                int i, e;
                cout << "Enter the value i : ";
                cin >> i;
                cout << "Enter the value e : ";
                cin >> e;
                list.set(i, e);
                list.display();
                break;
            }

            case 5: 
            {
                int i;
                cout << "Enter index to remove : ";
                cin >> i;
                list.remove(i);
                list.display();
                break;
            }
            
           case 6: {
                int i, e;
                cout << "Enter the value i : ";
                cin >> i;
                cout << "Enter the value e : ";
                cin >> e;

                list.add(i, e);
                list.display();
                break;
            }

            case 7: 
            {
                list.display();
                break;
            }

            case 8: 
            {
                cout << "Minimum element: " << list.min() << endl;
                break;
            }

            case 9: 
            {
                cout << "Maximum element: " << list.max() << endl;
                break;
            }

            case 10: 
            {
                list.clear();
                cout << "ArrayList cleared." << endl;
                break;
            }

            case 11: 
            {
                cout << "Is the ArrayList empty " << (list.isempty() ? "true" : "false") << endl;

                break;
            }

            case 0:
                cout << "Exit program." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
                break;
        }
    cout << "**************************" << endl;
    } while (choice != 0);

return 0;
}